<div class="review-section section-coupon-form">
    <h5 class="section-title">{{__('Coupon Code')}}</h5>
    <div class="input-group mb-3">
        <input type="text" class="form-control" >
        <div class="input-group-append">
            <button class="btn btn-primary" type="button" >{{__("Apply")}}</button>
        </div>
    </div>
</div>