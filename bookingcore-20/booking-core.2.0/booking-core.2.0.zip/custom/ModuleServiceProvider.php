<?php
/**
 * Created by PhpStorm.
 * User: Admin
 * Date: 7/29/2019
 * Time: 4:38 PM
 */
namespace Custom;
class ModuleServiceProvider extends \Modules\ModuleServiceProvider
{


}
