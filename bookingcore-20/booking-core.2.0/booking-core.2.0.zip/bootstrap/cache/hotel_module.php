<?php return array (
  'providers' => 
  array (
    0 => 'Plugins\\Hotel\\Providers\\HotelServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Plugins\\Hotel\\Providers\\HotelServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);