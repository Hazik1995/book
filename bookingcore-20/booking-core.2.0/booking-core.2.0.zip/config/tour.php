<?php
return [
    'tour_route_prefix' => env("TOUR_ROUTER_PREFIX","tour"),
];