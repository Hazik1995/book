<?php
return [
    'location_route_prefix' => env("LOCATION_ROUTER_PREFIX","location"),
];