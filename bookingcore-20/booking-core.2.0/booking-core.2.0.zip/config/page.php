<?php
return [
    'page_route_prefix' => env("PAGE_ROUTER_PREFIX","page"),
];